import React from 'react'

class First extends React.Component
{
  render(){
      return(
          <div>
             <h2>WELCOME TO MY REACT APPLICATION PAGE</h2>
             <p>Hello welcome to react </p><br></br>
             <ol>
                 <li>Mumbai</li>
                 <li>Kolkata</li>
                 <li>Delhi</li>
             </ol>
          </div>
      );
  }
}

export default First