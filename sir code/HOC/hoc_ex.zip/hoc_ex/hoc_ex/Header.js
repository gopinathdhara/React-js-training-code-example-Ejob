export default function Header(props) {
    return (
      <div className="App header">
        <h1>Hello CodeSandbox {props.count}</h1>
       <hr/>
      </div>
    );
  }
  